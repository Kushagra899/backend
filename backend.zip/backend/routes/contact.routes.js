const express = require("express");
const nodemailer = require("nodemailer");
const contactModel = require("../schemas/contact.model");
const router = express.Router();

router.post("/contactus", async (req, res) => {
  try {
    const { name, subject, message, email } = req.body;
    console.log(req.body);

    // Save to DB
    await contactModel.create(req.body);

    // Response before sending email
    res.send({
      message: "Contact form submitted successfully",
    });

    console.log("EMAIL_USER:", process.env.EMAIL_USER);
    console.log("EMAIL_PASS:", process.env.EMAIL_PASS ? "Loaded" : "Not Loaded");

    // Use Gmail SMTP instead of Ethereal
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,  // Use environment variable
        pass: process.env.EMAIL_PASS,
      },
    });

    let mailOption = {
      from: process.env.EMAIL_USER,  // Use authenticated email
      to: email,
      subject: subject,
      text: message,
    };

    transporter.sendMail(mailOption, (err, info) => {
      if (err) {
        console.log("Error occurred: " + err.message);
        return res.status(500).json({ error: "Failed to send email" });
      }

      console.log("Message sent: %s", info.messageId);
      res.json({ message: "Email sent successfully!" });
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/allmessage", async (req, res) => {
  try {
    let allMessage = await contactModel.find({});
    res.send(allMessage);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});

module.exports = router;
